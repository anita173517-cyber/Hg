package com.harindra.iptvpro

import java.util.Locale

/**
 * Ultra-lean Channel model for <=512 MB RAM Android Smart TVs (v16.0 Ultra Max Edition).
 * Preserves exact 8-field primary constructor compatibility while adding zero-overhead
 * helpers for Live TV, Movies (VOD), and Series classification.
 */
data class Channel(
    val id: String,
    val number: Int,
    val name: String,
    val category: String,
    val streamUrl: String,
    val logoUrl: String = "",
    val epgId: String = "",
    val backupUrl: String = ""
) {
    fun displayNumberFormatted(): String = when {
        number < 10 -> "00$number"
        number < 100 -> "0$number"
        else -> number.toString()
    }

    fun isVodMovie(): Boolean {
        val catLower = category.lowercase(Locale.ROOT)
        val urlLower = streamUrl.lowercase(Locale.ROOT)
        return catLower.contains("movie") ||
            catLower.contains("vod") ||
            catLower.contains("cinema") ||
            urlLower.contains("/movie/") ||
            urlLower.endsWith(".mp4") ||
            urlLower.endsWith(".mkv")
    }

    fun isSeriesEpisode(): Boolean {
        val catLower = category.lowercase(Locale.ROOT)
        val urlLower = streamUrl.lowercase(Locale.ROOT)
        return catLower.contains("series") ||
            catLower.contains("season") ||
            catLower.contains("web series") ||
            urlLower.contains("/series/")
    }

    companion object {
        const val DEFAULT_PROGRAM = "Live Broadcast"
        const val DEFAULT_NEXT_PROGRAM = "Upcoming Show"
    }
}

data class XtreamCredentials(
    val profileName: String,
    val serverUrl: String,
    val username: String,
    val password: String
)

data class EpgProgrammeDetail(
    val nowTitle: String,
    val nextTitle: String,
    val description: String = "",
    val timeWindow: String = "",
    val progressPercent: Int = 100
)
